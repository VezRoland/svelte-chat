<script>
    export let callback
</script>

<form on:submit|preventDefault={callback}>
    <input type="email" placeholder="email" name="email">
    <input type="password" name="password">
    <button type="submit">Log in</button>
</form>